-- Contar clientes
SELECT COUNT(*) AS total_clientes FROM clientes;

-- Edad promedio de empleados ficticios
-- (requiere tabla empleados)
-- SELECT AVG(edad) FROM empleados;
