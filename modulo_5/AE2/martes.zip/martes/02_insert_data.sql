INSERT INTO clientes VALUES
(1, 'Ana', 'ana@gmail.com'),
(2, 'Pedro', 'pedro@yahoo.com'),
(3, 'Lucía', 'lucia@gmail.com');

INSERT INTO pedidos VALUES
(1, 1, 'Laptop'),
(2, 2, 'Teclado'),
(3, 1, 'Mouse');
